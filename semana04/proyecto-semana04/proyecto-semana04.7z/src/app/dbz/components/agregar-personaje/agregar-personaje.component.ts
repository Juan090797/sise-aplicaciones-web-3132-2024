import { Component } from '@angular/core';

@Component({
  selector: 'app-agregar-dbz-personaje',
  standalone: true,
  imports: [],
  templateUrl: './agregar-personaje.component.html',
  styleUrl: './agregar-personaje.component.css'
})
export class AgregarPersonajeComponent {

}
